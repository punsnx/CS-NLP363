# ตัวอย่างโค้ด Chatbot ที่ตอบกลับแบบ if-else

## ติดตั้งก่อน (กรณีไม่ได้รันในdocker)
```
pip install -r requirements.txt

```

## อย่าลืมใส่!!
```
Channel_access_token=""
**ดูใน line bot ที่สร้างไว้
```